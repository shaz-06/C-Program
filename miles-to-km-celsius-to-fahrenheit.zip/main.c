/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//program to convert miles to Kilometer and Celsius to Fahrenheit//
#include <stdio.h>

int main()
{
    float m,km,c,f;
    printf("Enter distance in miles");
    scanf("%f",&m);
    km=m*1.60934;
    printf("%f m is equal to %f km\n",m,km);
    printf("Enter temperature in c");
    scanf("%f",&c);
    f=(c*9/5)+32;
    printf("%f c is equal to %f\n",c,f);
    return 0;
}